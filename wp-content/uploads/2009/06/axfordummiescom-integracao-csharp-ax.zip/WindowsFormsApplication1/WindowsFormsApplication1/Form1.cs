﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//Adicionando o assembly Net Business Conector do AX
using Microsoft.Dynamics.BusinessConnectorNet;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        Axapta ax;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnConectar_Click(object sender, EventArgs e)
        {
            try
            {
                //Instanciando o objeto que representa o AX
                ax = new Axapta();

                //Logando no sistema com a credencial do usuário conectado na máquina
                ax.Logon(null, null, null, null);

                //Mensagem de exibição de que estamos conectados!!
                MessageBox.Show("Conectado!");

                //Criando uma variável do tipo da tabela Book
                AxaptaRecord book = ax.CreateAxaptaRecord("Book");

                //Selecionando todos os registros da tabela
                book.ExecuteStmt("SELECT BookId, Title FROM %1");

                //Limpando as linhas do listbox
                lbRegistros.Items.Clear();

                //Percorrendo os registros retornados
                while (book.Found)
                {
                    //Adicionando registros no list box
                    lbRegistros.Items.Add(String.Format("{0} - {1}",
                                          book.get_Field("BookId").ToString(),
                                          book.get_Field("Title").ToString()
                                         ));
                    //Passando para o próximo registro
                    book.Next();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível conectar-se ao AX: " + ex.Message);
            }
        }

        private void btnDesconectar_Click(object sender, EventArgs e)
        {
            try
            {
                ax.Logoff();
                MessageBox.Show("Desconectado!");

                //Limpando as linhas do listbox
                lbRegistros.Items.Clear();

                //Limpando o campo de título do livro
                txtTituloLivro.Clear();

                //Limpando o campo de código do livro
                txtCodLivro.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Não foi possível desconectar-se do AX: " + ex.Message);
            }

        }

        private void btnPesquisar_Click(object sender, EventArgs e)
        {
            AxaptaRecord book;
            ;

            //Executando o método find da tabela "Book" e convertendo o tipo Object para um registro da tabela
            book = (AxaptaRecord) ax.CallStaticRecordMethod("Book", "find", txtCodLivro.Text);

            //Limpando as linhas do listbox
            lbRegistros.Items.Clear();

            //Adicionando a linha do registro encontrado
            lbRegistros.Items.Add(String.Format("Registro encontrado! {0}",book.get_Field("Title").ToString()));

            //Adicionando o título do livro no campo adequado
            txtTituloLivro.Text = book.get_Field("Title").ToString();
        }

        private void txtTituloLivro_KeyDown(object sender, KeyEventArgs e)
        {
            //Verificando se a tecla pressionada foi ENTER
            if (e.KeyCode == Keys.Enter)
            {
                //Se o campo txtCodLivro estiver diferente de vazio, atualizamos o registro
                //com o valor que está no campo txtTituloLivro se o encontrarmos. Caso contrário, inserimos um novo
                //Obtendo o valor do campo código
                
                //Obtendo o código do livro
                int bookId = Int32.Parse(txtCodLivro.Text.Trim() != "" ? txtCodLivro.Text : "0");

                //Pesquisando pelo registro a partir do seu código
                AxaptaRecord book = (AxaptaRecord)ax.CallStaticRecordMethod("Book", "find", bookId);

                //Se encontramos o registro, então vamos atualizá-lo
                if (book.Found)
                {
                    //Início da transação
                    ax.TTSBegin();

                    try
                    {
                        book.Call("selectForUpdate", true);

                        //Colocando o novo valor no campo título
                        book.set_Field("Title", txtTituloLivro.Text);

                        //Atualizando o registro
                        book.Update();

                        //Fim da transação
                        ax.TTSCommit();

                        //Mensagem de sucesso!
                        MessageBox.Show("Registro atualizado com sucesso!");
                    }
                    catch (Exception ex)
                    {
                        //Abortando a transação
                        ax.TTSAbort();

                        //Exibindo mensagem
                        MessageBox.Show("Erro ao editar registro: " + ex.Message);
                    }
                }
                else //Como não encontramos o registro, vamos inserí-lo
                {
                    //Criando um novo registro
                    book = ax.CreateAxaptaRecord("Book");

                    //um novo número será atribuído ao campo BookId
                    book.InitValue();
                    book.set_Field("Title", txtTituloLivro.Text);
                    book.Insert();

                    //Mensagem de sucesso
                    MessageBox.Show("Registro criado com sucesso!");
                }
            }
        }
    }
}
